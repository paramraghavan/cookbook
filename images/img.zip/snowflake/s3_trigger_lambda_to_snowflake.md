# Ingest, upsert, or add files from AWS S3 into Snowflake using an AWS Lambda function,

To ingest, upsert, or add files from AWS S3 into Snowflake using an AWS Lambda function, you can set up an S3 event
trigger to invoke the Lambda function whenever new data is added to the S3 bucket. The Lambda function can then use the
Snowflake Python connector to load the data into Snowflake.

## Set Up an S3 Event Trigger
1. Go to the S3 console and select your bucket.
2. Navigate to "Properties" and scroll down to the "Event notifications" section.
3. Create a new event notification to trigger the Lambda function whenever new files are added to the bucket. Specify
   the prefix (folder) or suffix (e.g., .csv) if needed.

## Create a Lambda Function
1. Go to the AWS Lambda console and create a new function.
2. Choose "Author from scratch" and configure the necessary execution role to allow access to S3 and Secrets Manager (
   for storing Snowflake credentials securely).
3. Add the Snowflake Python Connector to the Lambda layer or package it with your deployment package.

## Python Code for Lambda Function
```python
import boto3
import snowflake.connector
import os

def lambda_handler(event, context):
    # Parse S3 event data
    s3_event = event['Records'][0]['s3']
    bucket_name = s3_event['bucket']['name']
    file_key = s3_event['object']['key']
    
    # Set up S3 client
    s3_client = boto3.client('s3')
    
    # Download the file from S3 to /tmp directory
    download_path = f'/tmp/{file_key.split("/")[-1]}'
    s3_client.download_file(bucket_name, file_key, download_path)
    
    # Snowflake connection details (ideally use AWS Secrets Manager to store these)
    SNOWFLAKE_ACCOUNT = os.getenv('SNOWFLAKE_ACCOUNT')
    SNOWFLAKE_USER = os.getenv('SNOWFLAKE_USER')
    SNOWFLAKE_PASSWORD = os.getenv('SNOWFLAKE_PASSWORD')
    SNOWFLAKE_WAREHOUSE = os.getenv('SNOWFLAKE_WAREHOUSE')
    SNOWFLAKE_DATABASE = os.getenv('SNOWFLAKE_DATABASE')
    SNOWFLAKE_SCHEMA = os.getenv('SNOWFLAKE_SCHEMA')
    SNOWFLAKE_TABLE = os.getenv('SNOWFLAKE_TABLE')

    # Connect to Snowflake
    conn = snowflake.connector.connect(
        account=SNOWFLAKE_ACCOUNT,
        user=SNOWFLAKE_USER,
        password=SNOWFLAKE_PASSWORD,
        warehouse=SNOWFLAKE_WAREHOUSE,
        database=SNOWFLAKE_DATABASE,
        schema=SNOWFLAKE_SCHEMA
    )
    cursor = conn.cursor()

    # Load the data into Snowflake (assume CSV file for simplicity)
    try:
        # Stage the file in Snowflake
        cursor.execute(f"PUT file://{download_path} @%{SNOWFLAKE_TABLE}")
        
        # Copy the data into the table
        cursor.execute(f"""
            COPY INTO {SNOWFLAKE_TABLE}
            FROM @%{SNOWFLAKE_TABLE}/{file_key.split('/')[-1]}
            FILE_FORMAT = (type = 'CSV', field_optionally_enclosed_by = '"')
            ON_ERROR = 'CONTINUE';
        """)

        # Optionally perform an upsert
        cursor.execute(f"""
            MERGE INTO {SNOWFLAKE_TABLE} t
            USING (SELECT * FROM @%{SNOWFLAKE_TABLE}/{file_key.split('/')[-1]}) s
            ON t.id = s.id  -- Replace 'id' with the primary key column
            WHEN MATCHED THEN UPDATE SET t.col1 = s.col1, t.col2 = s.col2 -- Replace with actual columns
            WHEN NOT MATCHED THEN INSERT (col1, col2) VALUES (s.col1, s.col2); -- Replace with actual columns
        """)
    finally:
        cursor.close()
        conn.close()

    # Clean up the local file
    os.remove(download_path)

    return {
        'statusCode': 200,
        'body': f'Successfully processed {file_key} from {bucket_name}'
    }

```

## Above code explained

* S3 Trigger: The Lambda function is triggered by an S3 event whenever a new file is uploaded to the specified bucket.
* S3 Client: The function downloads the file from S3 to the Lambda /tmp directory.
* Snowflake Connection: The function connects to Snowflake using credentials stored in environment variables (you can
  also use AWS Secrets Manager).
* Data Loading: The file is staged in Snowflake and then loaded into the specified table using the COPY command.
* Upsert Logic: The MERGE command is used to upsert the data into the Snowflake table based on a matching key (e.g.,
  id).