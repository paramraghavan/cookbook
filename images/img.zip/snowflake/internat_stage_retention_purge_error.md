# Snowflake Internal Stage Retention, Purge Plan, and Error Handling

## 1. Retention and Purge Plan for Internal Stage

- **Retention**: Data files in Snowflake’s internal stage are automatically retained for a default period of 1 to 7
  days, depending on the type of internal stage (table stage, user stage, or named internal stage).
    - **Table Stage**: The data is retained for 1 day by default.
    - **User and Named Internal Stages**: The data is retained for up to 7 days.

- **Purge Plan**:
    - After the retention period expires, Snowflake automatically purges (deletes) the staged files.
    - You can also manually remove files from the internal stage using the `REMOVE` command if they are no longer needed
      before the retention period ends.

## 2. Data Handling After Copy/Ingestion

- **After Data is Copied/Ingested**:
    - Once data is successfully copied from the internal stage to a target table using the `COPY INTO` command, the
      original data files remain in the internal stage until the retention period ends.
    - These files can be removed manually using the `REMOVE` command or left to be purged automatically by Snowflake
      after the retention period.

- **Options for Managing Staged Files**:
    - If you want to delete files immediately after they are ingested, you can use the `PURGE` option in the `COPY INTO`
      command:
      ```sql
      COPY INTO my_table
      FROM @my_stage
      FILE_FORMAT = (TYPE = 'CSV')
      PURGE = TRUE;
      ```

## 3. Error Handling and Rollback

- **On Error Handling**:
    - **ABORT_STATEMENT**: The default behavior; the entire `COPY INTO` operation is aborted if an error occurs. No data
      is loaded.
    - **CONTINUE**: The operation skips the erroneous rows and continues loading the remaining data.
    - **SKIP_FILE**: Skips the entire file if an error occurs, based on a specified error threshold.

- **Rollback Handling**:
    - **Transaction Control**: If a transaction fails or a `ROLLBACK` is issued, all data loading operations within that
      transaction are undone, and no data is committed to the table.
    - **Partial Loads**: Snowflake ensures atomicity, meaning partial loads are rolled back, and no partial data is
      committed.

- **Error Files and Logging**:
    - Snowflake can generate error files capturing failed rows or files, which can be reviewed for debugging and
      reprocessing.

## Example of Error Handling During Copy

```sql
COPY INTO my_table
FROM @my_stage
FILE_FORMAT = (TYPE = 'CSV')
ON_ERROR = 'CONTINUE';
```

This command skips any rows with errors and continues loading the rest of the data into `my_table`.
