Staging a file in Snowflake and then loading it into a table using the COPY command is a two-step process that is
central to data ingestion workflows in Snowflake

# Staging the File in Snowflake

**Staging** in Snowflake refers to the process of uploading data files (like CSV, JSON, etc.) from external storage (
such as AWS S3) or local storage (like your Lambda function's /tmp directory) into a Snowflake internal stage. Staging
is necessary because it allows Snowflake to efficiently manage, validate, and access files before loading them into a
table.

1. Internal Stage: An internal stage is a storage location within Snowflake that temporarily holds the data files. **Each
   Snowflake table automatically has its own internal stage (denoted as @%<table_name>)**. You can also create named
   stages that can be reused across different tables and databases.
2. PUT Command: To upload a file to the internal stage, you use the PUT command in Snowflake. This command copies the
   file from the specified local path (in the Lambda function, it’s the /tmp directory) to the internal stage.

Example of the PUT command:

```sql
PUT file://path/to/local/file.csv @%table_name;
```
* file://path/to/local/file.csv: This is the path to the local file you want to upload (in this case, the file
  downloaded from S3 to Lambda’s /tmp directory).
* %table_name: This refers to the internal stage associated with a specific table in Snowflake.


# Loading the Staged File into the Table Using the COPY Command

Once the file is successfully staged, you use the COPY INTO command to load the data from the stage into a Snowflake
table. The COPY INTO command reads the file from the internal stage and inserts the data into the target table.

- COPY INTO Command: The COPY INTO command is highly flexible and allows you to specify various options, such as file
  format, data transformations, and error handling.

Example of the COPY INTO command:
```sql
COPY INTO table_name
FROM @%table_name/file_name.csv
FILE_FORMAT = (TYPE = 'CSV', FIELD_OPTIONALLY_ENCLOSED_BY = '"')
ON_ERROR = 'CONTINUE';
```
* table_name: The target table in Snowflake where the data will be loaded.
* @%table_name/file_name.csv: The location of the file within the internal stage associated with the table.
* FILE_FORMAT: Specifies the format of the file. In this example, the file is a CSV with fields optionally enclosed by double quotes.
* ON_ERROR = 'CONTINUE': This option tells Snowflake to continue loading even if some rows have errors (you can also set it to 'ABORT_STATEMENT' to stop on the first error).

## How It Works Together
* Download File: In the Lambda function, you first download the file from S3 to a temporary local directory (/tmp).
* Stage File: You then stage the file in Snowflake by uploading it to the internal stage using the PUT command.
* Load Data: After staging, you use the COPY INTO command to load the data from the staged file into the specified Snowflake table.
* Optional: Upsert/Merge: If needed, after loading the data, you can run a MERGE statement to upsert the data into the target table, ensuring that existing records are updated and new records are inserted.

## Benefits of Staging and Loading
* Efficiency: Staging allows Snowflake to perform optimizations on the data before it is loaded, ensuring faster and more reliable data loads.
* Control: By separating the staging and loading steps, you gain more control over the data loading process. For instance, you can validate data in the stage before loading it.
* Error Handling: Snowflake provides robust error handling during the COPY process, allowing you to control how errors are managed (e.g., skipping bad rows or aborting the load).

## Example Workflow in Lambda Function

- Download the file from S3 to the Lambda's /tmp directory.
- Stage the file in Snowflake using the PUT command:

```python
cursor.execute(f"PUT file://{download_path} @%{SNOWFLAKE_TABLE}")
```
- Load the staged data into the Snowflake table using the COPY INTO command:

```python
cursor.execute(f"""
    COPY INTO {SNOWFLAKE_TABLE}
    FROM @%{SNOWFLAKE_TABLE}/{file_key.split('/')[-1]}
    FILE_FORMAT = (type = 'CSV', field_optionally_enclosed_by = '"')
    ON_ERROR = 'CONTINUE';
""")
```