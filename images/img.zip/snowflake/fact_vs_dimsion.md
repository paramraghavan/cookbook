In the context of data warehousing and business intelligence, **facts and dimensions** are two key concepts that form the basis of a star schema or snowflake schema. Understanding the difference between these two types of tables is essential for designing and querying a data warehouse effectively.

## Fact Tables
Fact tables are the central tables in a star schema or snowflake schema, and they store quantitative data for analysis. These tables contain the measurements, metrics, or facts of a business process. Each record in a fact table corresponds to a specific event or transaction, such as a sale, order, or financial transaction.

### Key Characteristics of Fact Tables:
Measures/Metrics: _Fact tables contain numerical data that can be aggregated, such as sales revenue, quantity sold, or profit._
Foreign Keys: Fact tables typically have foreign keys that reference primary keys in dimension tables. These foreign keys relate the facts to the descriptive attributes stored in dimension tables.
Granularity: The granularity of a fact table refers to the level of detail in the data. For example, a sales fact table might have a row for each sale (transaction-level granularity) or a row for each daily total (daily-level granularity).
Additivity: Most facts are additive, meaning they can be summed across dimensions (e.g., total sales). Some facts are semi-additive (e.g., account balances) or non-additive (e.g., ratios or percentages).

**Example of a Fact Table:**
Consider a sales fact table that records each sale transaction:
```text
Transaction_ID	Date	Product_ID	Store_ID	Quantity_Sold	Sales_Amount
1	            2024-08-01	101	        1	        2	        50.00
2	            2024-08-01	102	        2	        1	        30.00
3	            2024-08-02	101	        1	        3	        75.00
```
## Dimension Tables

_Dimension tables are tables in a star or snowflake schema that store descriptive attributes related to the facts_. These
attributes are typically textual or categorical data, such as customer names, product descriptions, or time periods.
Dimension tables provide context to the facts, enabling users to perform detailed analysis and drill-downs in reports.

### Key Characteristics of Dimension Tables:
Descriptive Attributes: Dimension tables contain descriptive, qualitative information, such as names, categories, dates, and locations.
Primary Keys: Each dimension table has a primary key, which uniquely identifies each record in the table. This primary key is referenced by the foreign keys in the fact table.
Hierarchies: Dimension tables often contain hierarchical relationships (e.g., Year > Quarter > Month > Day in a time dimension) that allow for drill-down analysis in reports.
Denormalization: Dimension tables are typically denormalized for ease of use and query performance. This means they may include redundant data to reduce the complexity of joins.

**Example of a Dimension Table:**
Consider a product dimension table that describes products:
```text
Product_ID	Product_Name	Category	Brand	Price
101	        Widget A	    Widgets	    Brand X	25.00
102	        Gadget B	    Gadgets	    Brand Y	30.00
```

In a star schema, fact tables and dimension tables are joined together using foreign key-primary key relationships. The
fact table serves as the central hub of the schema, while dimension tables radiate out from it like the points of a
star. This structure allows for efficient querying and analysis of the data. For example, you can query the sales fact
table to find total sales by product category, store, or time period by joining it with the relevant dimension tables.

Conclusion
Understanding the difference between fact and dimension tables is crucial for designing effective data warehouse schemas and performing meaningful data analysis. Fact tables contain the quantifiable data of interest, while dimension tables provide the descriptive context that allows you to explore and analyze that data in detail.