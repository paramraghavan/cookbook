# Using `MERGE` in Snowflake

The `MERGE` statement in Snowflake is used to synchronize two tables based on specified conditions. This powerful SQL command allows you to update, insert, or delete rows in a target table by comparing it with a source table (or subquery). It's particularly useful when dealing with data integration, ETL processes, or situations where you need to keep two datasets in sync.

## Key Use Cases of `MERGE` in Snowflake

1. **Upsert Operations (Update or Insert):**
   - The most common use of `MERGE` is to perform an upsert operation. This means updating existing rows if they match a condition or inserting new rows if they don’t exist.

2. **Data Synchronization:**
   - `MERGE` is ideal for syncing data between a staging table and a target table. For example, you might have a daily batch of updates that need to be applied to your main data warehouse tables.

3. **Slowly Changing Dimensions (SCD):**
   - In data warehousing, particularly in dimensional modeling, `MERGE` is used to handle slowly changing dimensions. This involves updating records in the dimension table while keeping track of historical data.

4. **Conditional Deletes:**
   - Although not as common, `MERGE` can also be used to delete records in a target table that do not match the source. This might be used in scenarios where you need to remove obsolete data.

## Example Scenarios

### 1. Upsert Data

Imagine you have a `customer` table in your database and you receive daily updates in a `customer_updates` table. You want to update the existing customer records or insert new ones if they don't exist.

```sql
MERGE INTO customer AS target
USING customer_updates AS source
ON target.customer_id = source.customer_id
WHEN MATCHED THEN
    UPDATE SET
        target.customer_name = source.customer_name,
        target.email = source.email,
        target.phone_number = source.phone_number
WHEN NOT MATCHED THEN
    INSERT (customer_id, customer_name, email, phone_number)
    VALUES (source.customer_id, source.customer_name, source.email, source.phone_number);
```

### 2. Sync Staging Table to Target Table
Suppose you have a staging table stg_sales with daily sales data, and you need to update your main sales table with this data.
```sql
MERGE INTO sales AS target
USING stg_sales AS source
ON target.order_id = source.order_id
WHEN MATCHED THEN
    UPDATE SET
        target.order_date = source.order_date,
        target.amount = source.amount,
        target.customer_id = source.customer_id
WHEN NOT MATCHED THEN
    INSERT (order_id, order_date, amount, customer_id)
    VALUES (source.order_id, source.order_date, source.amount, source.customer_id);
```

### 3. Implementing Slowly Changing Dimensions (SCD Type 2)

You might have a products dimension table where you want to track changes in product details over time while preserving
history.
```sql
MERGE INTO products AS target
USING stg_products AS source
ON target.product_id = source.product_id AND target.current_flag = 'Y'
WHEN MATCHED AND target.product_name != source.product_name THEN
    UPDATE SET target.current_flag = 'N', target.end_date = CURRENT_DATE
WHEN NOT MATCHED THEN
    INSERT (product_id, product_name, current_flag, start_date, end_date)
    VALUES (source.product_id, source.product_name, 'Y', CURRENT_DATE, NULL);
```

## Best Practices for Using MERGE in Snowflake

1. Indexing: Ensure that your tables are indexed on the columns used in the ON condition for faster query performance.
3. Test on Small Datasets: Before running MERGE on large tables, test it on smaller datasets to ensure it behaves as
   expected.
4. Use MERGE Carefully: Since MERGE can modify large numbers of rows, ensure that the logic is correct to avoid
   unintended data changes.
5. Error Handling: Implement error handling or monitoring to track the success or failure of MERGE operations,
   especially in production environments.
6. Performance Considerations: Monitor the performance of MERGE statements, especially with large datasets. Use
   appropriate Snowflake warehouse sizes and optimize the query if needed.
7. Versioning: For slowly changing dimensions, consider maintaining version numbers or timestamps to track changes over
   time.

The MERGE statement in Snowflake is a versatile tool that can greatly simplify complex data operations, particularly in
ETL processes and data warehousing. By carefully structuring your MERGE queries and considering performance
implications, you can efficiently manage and synchronize your data.


## Merge and delete

Suppose you have a customers table, and **you receive a list of inactive customers** in a inactive_customers table. _You want
to delete the records of these inactive customers from the customers table._

Here’s how you can use the MERGE statement to perform this deletion:
```sql
MERGE INTO customers AS target
USING inactive_customers AS source
ON target.customer_id = source.customer_id
WHEN MATCHED THEN DELETE;
```

### Partial Deletion with Additional Conditions

You can also add additional conditions to selectively delete records. For example, if you want to delete only inactive
customers who have not made any purchases in the last year:
```sql
MERGE INTO customers AS target
USING inactive_customers AS source
ON target.customer_id = source.customer_id
WHEN MATCHED AND target.last_purchase_date < '2023-01-01' THEN DELETE;
```
