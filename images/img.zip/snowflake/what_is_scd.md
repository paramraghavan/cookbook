# Slowly Changing Dimensions (SCD)

## What is a Slowly Changing Dimension?

In data warehousing, a **Slowly Changing Dimension (SCD)** is a concept used to manage and track changes in dimension data over time. Dimensions are typically descriptive attributes related to fact data, such as customer information, product details, or employee data. Since these attributes may change slowly and unpredictably over time, various methods have been developed to handle these changes while preserving historical data or reflecting the most current information.

There are several types of Slowly Changing Dimensions, each designed to handle changes differently. The most common types are SCD Type 0, Type 1, Type 2, Type 3, and Type 4.

## SCD Types with Examples

### 1. SCD Type 0: Retain Original

**SCD Type 0** involves no changes to the data once it is initially loaded into the dimension table. The original data is preserved without any updates.

**Example:**

- **Initial Record:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: New York

- **After Location Change:**
  - The `Location` remains `New York`, even if Alice moves to another city.

### 2. SCD Type 1: Overwrite

**SCD Type 1** involves updating the existing record with new data, effectively overwriting the old data. Historical data is lost as the changes are not tracked.

**Example:**

- **Initial Record:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: New York

- **After Location Change:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: San Francisco
  
  The `Location` is updated to `San Francisco`, and the previous value (`New York`) is lost.

### 3. SCD Type 2: Add New Record

**SCD Type 2** involves creating a new record in the dimension table to track the changes while preserving the historical data. This approach maintains a full history of data changes.

**Example:**

- **Initial Record:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: New York
  - `Start_Date`: 2021-01-01
  - `End_Date`: NULL (indicating the current record)
  - `Current_Flag`: Y
  - `Version`: 1

- **After Location Change:**
  - **Old Record:**
    - `Employee_ID`: 101
    - `Name`: Alice
    - `Department`: Sales
    - `Location`: New York
    - `Start_Date`: 2021-01-01
    - `End_Date`: 2023-06-01
    - `Current_Flag`: N
    - `Version`: 1
  - **New Record:**
    - `Employee_ID`: 101
    - `Name`: Alice
    - `Department`: Sales
    - `Location`: San Francisco
    - `Start_Date`: 2023-06-01
    - `End_Date`: NULL
    - `Current_Flag`: Y
    - `Version`: 2
  
  A new record is created for the `San Francisco` location, while the `New York` location is retained as historical data.

### 4. SCD Type 3: Add New Column

**SCD Type 3** involves adding a new column to the dimension table to store the previous value of the attribute that changes. This method allows for limited historical tracking, typically one previous version.

**Example:**

- **Initial Record:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Current_Location`: New York
  - `Previous_Location`: NULL

- **After Location Change:**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Current_Location`: San Francisco
  - `Previous_Location`: New York
  
  The `Current_Location` is updated to `San Francisco`, and the `Previous_Location` is set to `New York`.

### 5. SCD Type 4: Add Historical Table

**SCD Type 4** involves using a separate historical table to track changes. The main dimension table stores only the current data, while a separate historical table keeps a record of all changes.

**Example:**

- **Main Dimension Table (`employee_dim`):**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: San Francisco

- **Historical Table (`employee_history`):**
  - `Employee_ID`: 101
  - `Name`: Alice
  - `Department`: Sales
  - `Location`: New York
  - `Start_Date`: 2021-01-01
  - `End_Date`: 2023-06-01
  
  The main table reflects the current location (`San Francisco`), while the historical table keeps a record of the previous location (`New York`).

## Conclusion

Slowly Changing Dimensions (SCD) are essential in data warehousing to manage and track changes in dimension data over time. Each SCD type has its own approach to handling changes, from simply overwriting data to preserving full historical records. The choice of SCD type depends on the specific business requirements and the need for historical data in reporting and analysis.
