# Storing Data in S3 and Using Snowflake’s External Tables or Direct File Querying

When storing data in S3 and using Snowflake’s external tables or direct file querying, you can efficiently manage and
query your data without loading it into Snowflake tables. This approach is particularly useful for large datasets, raw
data, or data that doesn't require frequent or complex queries. Below, I’ll guide you through the process of setting
this up.

## Step 1: Storing Data in S3

First, you’ll need to upload your data files to an S3 bucket. These files can be in various formats such as CSV, JSON,
Parquet, Avro, ORC, etc.

### Example: Uploading Data to S3

- **S3 Bucket**: `s3://my-data-bucket/`
- **Folder**: `raw-data/`
- **Files**: `data1.csv`, `data2.json`, `data3.parquet`, etc.

Your S3 structure might look like this:

```
s3://my-data-bucket/
    └── raw-data/
        ├── data1.csv
        ├── data2.json
        └── data3.parquet
```

## Step 2: Setting Up Snowflake External Stage

An external stage in Snowflake is a reference to an external location, such as an S3 bucket, where your data is stored.
This allows Snowflake to access and query the data directly from S3.

### Example: Create an External Stage

```sql
CREATE OR REPLACE STAGE my_s3_stage
URL='s3://my-data-bucket/raw-data/'
CREDENTIALS=(AWS_KEY_ID='<your_aws_access_key_id>' AWS_SECRET_KEY='<your_aws_secret_key>')
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);
```

- **`URL`**: The S3 bucket and folder where your data resides.
- **`CREDENTIALS`**: Your AWS access key and secret key. Alternatively, you can use IAM roles if you're using Snowflake
  with AWS.
- **`FILE_FORMAT`**: Specifies the format of the data files. In this example, it's CSV, but you can adjust this based on
  your file type.

### Using IAM Roles with Snowflake instead of ASW credentials

When using IAM roles, you do not need to provide AWS_KEY_ID and AWS_SECRET_KEY in the CREDENTIALS clause. Instead, you
will set up an IAM role in AWS with the necessary permiss

- Create an IAM Role in AWS
    - Create an IAM role with S3 read/write permissions.
    - Configure a trust relationship in the IAM role to allow Snowflake to assume the role. The trust policy should look
      something like this:
  ```json
        {
          "Version": "2012-10-17",
          "Statement": [
            {
              "Effect": "Allow",
              "Principal": {
                "Service": "snowflake.amazonaws.com"
              },
              "Action": "sts:AssumeRole"
            }
          ]
        }
   ```
- Attach the IAM Role to Snowflake
    - Attach the IAM role to your Snowflake account using the following SQL command:
  ```sql
    CREATE OR REPLACE STORAGE INTEGRATION my_s3_integration
    TYPE = EXTERNAL_STAGE
    STORAGE_PROVIDER = 'S3'
    ENABLED = TRUE
    STORAGE_AWS_ROLE_ARN = '<your_aws_role_arn>'
    STORAGE_ALLOWED_LOCATIONS = ('s3://my-data-bucket/');
  ```

- Create the Stage Using the IAM Role
  Now, create the external stage without specifying AWS credentials, but using the storage integration instead:
  ```sql
  CREATE OR REPLACE STAGE my_s3_stage
  URL='s3://my-data-bucket/raw-data/'
  STORAGE_INTEGRATION = my_s3_integration
  FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);
  ```

## Step 3: Creating an External Table

An external table in Snowflake allows you to define a table schema on top of the data stored in S3, enabling you to
query it using SQL.

### Example: Create an External Table

```sql
CREATE OR REPLACE EXTERNAL TABLE my_external_table (
    id INT,
    name STRING,
    age INT,
    country STRING
)
LOCATION=@my_s3_stage
FILE_FORMAT = (TYPE = 'CSV');
```

- **`LOCATION`**: References the external stage where your data is stored.
- **`FILE_FORMAT`**: Specifies the file format of the data.

## Step 4: Querying the External Table

Once the external table is set up, you can query it just like any other table in Snowflake.

### Example: Query Data from External Table

```sql
SELECT * FROM my_external_table WHERE age > 30;
```

This query will fetch data from the CSV files stored in S3 and return only the rows where the `age` is greater than 30.

## Step 5: Direct File Querying (Snowflake’s `SELECT FROM`)

Snowflake also allows you to directly query files stored in S3 without creating an external table. This is useful for
ad-hoc queries or when you don’t want to define a full table schema.

### Example: Query a CSV File Directly

```sql
SELECT $1 AS id, $2 AS name, $3 AS age, $4 AS country
FROM @my_s3_stage/data1.csv;
```

- **`$1`, `$2`, etc.**: These are placeholders for the columns in your CSV file. You can alias them as needed.

## Step 6: Optimizations and Best Practices

1. **Partitioning Data**: Organize your data in S3 by partitioning it (e.g., by date or region) to improve query
   performance.
    - Example:
      ```
      s3://my-data-bucket/
          └── raw-data/
              ├── 2024/
              │   ├── 01/
              │   │   └── data1.csv
              │   └── 02/
              │       └── data2.csv
              └── 2023/
                  └── 12/
                      └── data3.csv
      ```

2. **File Formats**: Use columnar file formats like Parquet or ORC if your queries only need to access specific columns.
   These formats are optimized for performance in large-scale data processing.

3. **Metadata Management**: Keep track of the metadata and schemas of the data files in S3 to ensure consistency when
   querying.

## Summary

Storing data in S3 and using Snowflake’s external tables or direct file querying provides a flexible and cost-effective
way to manage large datasets, especially when the data doesn’t require frequent access. You can load only the necessary
data into Snowflake for processing or directly query the data in S3 as needed.

This approach allows you to benefit from the low-cost storage of S3 while leveraging Snowflake’s powerful query
capabilities.
